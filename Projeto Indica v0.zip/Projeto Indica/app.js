// app.js
const express = require('express');
const path = require('path');
const sequelize = require('./sequelize');
const Produto = require('./models/produto');

const app = express();

// Exemplo: Criar uma nova entrada na tabela Produto
app.post('/criar-produto', async (req, res) => {
  try {
    const imagePath = path.join(__dirname, 'images'); // Caminho para a pasta de imagens

    const novoProduto = await Produto.create({
      foto: path.join(imagePath, 'nome_da_foto.jpg'), // Substitua 'nome_da_foto.jpg' pelo nome real da foto
      descricao: 'Descrição do produto...',
      temVideoUnboxing: true,
      linkVideoUnboxing: 'https://www.youtube.com/unboxingvideo',
    });

    res.json(novoProduto);
  } catch (error) {
    console.error('Erro ao criar o produto:', error);
    res.status(500).json({ error: 'Erro ao criar o produto' });
  }
});

// Iniciar o servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
