const mysql = require('mysql2/promise');

// Configuração da conexão com o banco de dados MySQL
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '', // Senha do seu banco de dados, se houver
  database: 'geekIndica'
});

// Função para inserir um novo produto no banco de dados
async function inserirProduto() {
  try {
    // Observe que estes dados devem vir da sua aplicação
    const foto = '/caminho/para/a/foto.jpg';
    const descricao = 'Descrição do produto...';
    const temVideoUnboxing = true;
    const linkVideoUnboxing = 'https://www.youtube.com/unboxingvideo';
    const linksCompra = [
      { storeName: 'Loja 1', storeLink: 'https://www.loja1.com/produto123' },
      { storeName: 'Loja 2', storeLink: 'https://www.loja2.com/produto123' }
    ];

    // Iniciar uma transação
    const connection = await pool.getConnection();
    await connection.beginTransaction();

    // Inserir o novo produto na tabela 'produtos'
    const [result] = await connection.query('INSERT INTO produtos (foto, descricao, tem_video_unboxing, link_video_unboxing) VALUES (?, ?, ?, ?)', [foto, descricao, temVideoUnboxing, linkVideoUnboxing]);

    // Recuperar o ID do novo produto inserido
    const novoProdutoId = result.insertId;

    // Inserir os links de compra na tabela 'links_compra', relacionados ao novo produto
    for (const link of linksCompra) {
      await connection.query('INSERT INTO links_compra (produto_id, loja_nome, loja_link) VALUES (?, ?, ?)', [novoProdutoId, link.storeName, link.storeLink]);
    }

    // Commit da transação
    await connection.commit();
    connection.release();

    console.log('Produto inserido com sucesso!');
  } catch (error) {
    console.error('Erro ao inserir o produto:', error);
  }
}

// Chamada da função para inserir um novo produto (remova isso para evitar a execução automática)
// inserirProduto();
