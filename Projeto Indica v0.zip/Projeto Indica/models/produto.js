// models/produto.js
const { DataTypes } = require('sequelize');
const sequelize = require('../sequelize');

const Produto = sequelize.define('Produto', {
  foto: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  descricao: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  temVideoUnboxing: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
  },
  linkVideoUnboxing: {
    type: DataTypes.STRING,
    allowNull: true,
  },
});

module.exports = Produto;
