// sequelize.js
const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('geekIndica', 'seu_usuario', 'sua_senha', {
  host: 'localhost',
  dialect: 'mysql',
});

module.exports = sequelize;
